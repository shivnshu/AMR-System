#pragma once
#include "../TKernel/Precompiled.h"
#include "../TKMath/Precompiled.h"
#include "../TKGeomBase/Precompiled.h"
#include "../TKG2d/Precompiled.h"
#include "../TKG3d/Precompiled.h"