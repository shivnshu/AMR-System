#pragma once

#include "../TKTopAlgo/Precompiled.h"
#include "../TKBO/Precompiled.h"
#include "../TKPrim/Precompiled.h"
#include "../TKShHealing/Precompiled.h"

#include "BRepFeat.hxx"
#include "BRepFeat_Builder.hxx"
#include "LocOpe.hxx"
