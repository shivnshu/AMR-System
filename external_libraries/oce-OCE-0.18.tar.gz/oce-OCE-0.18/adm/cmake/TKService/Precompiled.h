#pragma once

#include "../TKernel/Precompiled.h"
#include "../TKMath/Precompiled.h"

#include "Standard.hxx"
#include "Aspect_Handle.hxx"
#include "SelectBasics.hxx"
