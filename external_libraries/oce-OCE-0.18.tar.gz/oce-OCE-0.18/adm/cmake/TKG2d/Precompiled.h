#pragma once
#include "../TKernel/Precompiled.h"
#include "../TKMath/Precompiled.h"
#include "Geom2d_Geometry.hxx"
#include "Geom2d_Curve.hxx"
#include "Adaptor2d_Curve2d.hxx"
#include "Adaptor2d_HCurve2d.hxx"
