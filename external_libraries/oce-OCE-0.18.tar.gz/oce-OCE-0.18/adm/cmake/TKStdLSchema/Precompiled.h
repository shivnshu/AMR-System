#pragma once
#include "../TKG2d/Precompiled.h"
#include "../TKG3d/Precompiled.h"
#include "../TKBRep/Precompiled.h"

#include "../PTKernel/Precompiled.h"
#include "../TKCDF/Precompiled.h"
