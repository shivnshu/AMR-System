## OCE contributors

OCE contains additional code over OCCT contributed by (alphabetical sort):

- Jacob Abel (https://github.com/thatcadguy)
- Guillaume Alleon (guillaume.alleon at gmail dot com)
- Greg Allen ()
- Denis Barbier (bouzim at gmail dot com, https://github.com/dbarbier)
- Benjamin Bihler (https://github.com/Bihlerben)
- @blobfish (https://github.com/blobfish)
- fohlenrolle (mmuellen at gmx dot de)
- QbProg (tholag at gmail dot com)
- Jake ()
- Johannes Obermayr (https://github.com/jobermayr)
- Peter Lama (https://github.com/peterl94s)
- Mario Lang ()
- Thomas Paviot (tpaviot at gmail dot com)
- Mark Pictor (mpictor at gmail dot com, https://github.com/mpictor)
- Conrad Poelman ()
- Jérôme Robert (jrobert dot pro at gmail dot com, https://github.com/jeromerobert)
- David Sankel ()
- Richard Shaw ()
- Martin Siggel (https://github.com/rainman110)
- Fotis Sioutis (sfotis at gmail dot com, https://github.com/sfotis)
- Daniel Somer ()
- Hugh Sorby (https://github.com/hsorby)
- Hugues Delorme ()
- Philippe Carret ()
- He Yuki ()

Copyright 2011-2015
