#pragma once

#include "../TKTopAlgo/Precompiled.h"
#include "BRepPrim_Builder.hxx"
#include "BRepPrimAPI_MakeBox.hxx"
#include "BRepPrimAPI_MakeCylinder.hxx"
#include "BRepSweep_Builder.hxx"
#include "BRepSweep_Tool.hxx"